This IPython notebook forces.ipynb does not require any additional
programs.
