This IPython notebook mc.ipynb does not require any additional
programs.
