This IPython notebook angmom.ipynb does not require any additional
programs.
