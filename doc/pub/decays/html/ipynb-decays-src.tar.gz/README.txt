This IPython notebook decays.ipynb does not require any additional
programs.
